package com.threatmonitor.beans;

public class generateProcesses {

	String ProcessesCodes;
	String DateTimeStamp;
	public String getProcessesCodes() {
		return ProcessesCodes;
	}
	public void setProcessesCodes(String processesCodes) {
		ProcessesCodes = processesCodes;
	}
	public String getDateTimeStamp() {
		return DateTimeStamp;
	}
	public void setDateTimeStamp(String dateTimeStamp) {
		DateTimeStamp = dateTimeStamp;
	}



}
