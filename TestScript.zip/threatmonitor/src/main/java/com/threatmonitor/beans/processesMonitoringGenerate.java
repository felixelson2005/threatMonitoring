package com.threatmonitor.beans;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Test;

import com.google.gson.Gson;

public class processesMonitoringGenerate {

	private static FileWriter filewriter;
	private static JSONObject  generateProcess() {

		JSONObject ProcessCreationjson = new JSONObject();

		try {

			int sum=5;

			for(int i=0;i<sum;i++) {

				String randomNumber = String.valueOf((int) (Math.random() * 99999) + 11111);

				String timeStamp = new SimpleDateFormat("yy/MM/dd HH:mm:ss").format(new Date());

				System.out.println(randomNumber+timeStamp);

				ProcessCreationjson.put(randomNumber, timeStamp);

				Thread.sleep(1000);

			}
		}catch(Exception e) {
			e.printStackTrace();

		}

		System.out.println(ProcessCreationjson);

		return ProcessCreationjson;

	}


	private static JSONObject JsonFileUpdation(JSONObject obj) throws IOException {

		JSONObject returnobj;

		try {
			returnobj=obj;
			filewriter = new FileWriter(System.getProperty("user.dir")+"//src//main//resources//processCodefile.json");
			filewriter.write(obj.toString());
			filewriter.close();

			return returnobj;

		}catch(Exception e) {

			e.printStackTrace();
			return null;
		}

	}


	public void GenerateProcess() {
		try {

			JsonFileUpdation(generateProcess());

		}catch(Exception e) {

			System.out.println(e);

		}

	}


	public void readexistingProcesswithin60seconds() {

		try {

			GenerateProcess();

			JSONParser jsonParser = new JSONParser();

			FileReader reader = new FileReader(System.getProperty("user.dir")+"//src//main//resources//processCodefile.json");

			Object obj = jsonParser.parse(reader);
			String jsonInString = new Gson().toJson(obj);
			JSONObject mJSONObject = new JSONObject(jsonInString);

			JSONObject ProcessExistingjson = mJSONObject;

			System.out.println();

			JSONObject ExtendProcess=new JSONObject();

			Iterator<String> keys= ProcessExistingjson.keys();

			int changecount=0;

			while(keys.hasNext()) {

				String processcode=keys.next();
				String newtimeStamp = new SimpleDateFormat("yy/MM/dd HH:mm:ss").format(new Date());
				String oldtimestamp=ProcessExistingjson.getString(processcode);

				ExtendProcess.put(processcode, newtimeStamp);



				if(timeDifferbetween2dates(oldtimestamp,newtimeStamp)) {
					int counter=0;
					System.out.println("Process tracked less than in 60 seconds");
					System.out.println("Not updating the file with process and stamp");
					System.out.println("Counter value is"+counter++);

				}else {
					System.out.println("Process tracked more than in 60 seconds");
					ProcessExistingjson.put(processcode, newtimeStamp);
					changecount++;
				}

			}

			if(changecount>0) {

				JsonFileUpdation(ProcessExistingjson);

			}else {

				System.out.println("No updates made");


			}
		}catch(Exception e) {

			e.printStackTrace();

		}

	}


	public void readexistingProcessMoreThan60seconds() {

		try {

			GenerateProcess();

			TimeUnit.SECONDS.sleep(61);

			JSONParser jsonParser = new JSONParser();

			FileReader reader = new FileReader(System.getProperty("user.dir")+"//src//main//resources//processCodefile.json");

			Object obj = jsonParser.parse(reader);
			String jsonInString = new Gson().toJson(obj);
			JSONObject mJSONObject = new JSONObject(jsonInString);

			JSONObject ProcessExistingjson = mJSONObject;

			System.out.println();

			JSONObject ExtendProcess=new JSONObject();

			Iterator<String> keys= ProcessExistingjson.keys();

			int changecount=0;

			while(keys.hasNext()) {

				String processcode=keys.next();
				String newtimeStamp = new SimpleDateFormat("yy/MM/dd HH:mm:ss").format(new Date());
				String oldtimestamp=ProcessExistingjson.getString(processcode);

				ExtendProcess.put(processcode, newtimeStamp);

				if(timeDifferbetween2dates(oldtimestamp,newtimeStamp)) {
					int counter=0;
					System.out.println("Process tracked less than in 60 seconds");
					System.out.println("Not updating the file with process and stamp");
					System.out.println("Counter value is"+counter++);

				}else {
					System.out.println("Process tracked more than in 60 seconds");
					ProcessExistingjson.put(processcode, newtimeStamp);
					changecount++;
				}

			}

			if(changecount>0) {

				JsonFileUpdation(ProcessExistingjson);

			}else {

				System.out.println("No updates made");


			}
		}catch(Exception e) {

			e.printStackTrace();

		}

	}


	@Test
	public void readnewProcesslessthan60seconds() {

		try {

			GenerateProcess();

			JSONParser jsonParser = new JSONParser();

			FileReader reader = new FileReader(System.getProperty("user.dir")+"//src//main//resources//processCodefile.json");

			Object obj = jsonParser.parse(reader);
			String jsonInString = new Gson().toJson(obj);
			JSONObject mJSONObject = new JSONObject(jsonInString);

			JSONObject ProcessExistingjson = mJSONObject;

			System.out.println();

			int counter=0;

			JSONObject ExtendProcess=generateProcess();

			Iterator<String> keys= ExtendProcess.keys();

			while(keys.hasNext()) {

				String newprocessCode=keys.next();
				if(ProcessExistingjson.has(newprocessCode)) {
					System.out.println("No capturing is required");
				}else {

					System.out.println("Update to the existing file");
					ProcessExistingjson.put(newprocessCode, ExtendProcess.get(newprocessCode));
					counter++;

				}
			}

			if(counter>0) {
				System.out.println("Json Update is required");
				JsonFileUpdation(ProcessExistingjson);
			}else {
				System.out.println("Json Update is not required as there is no new process");
			}

		}catch(Exception e) {

			e.printStackTrace();

		}

	}

	public static boolean newprocessIdentified(String oldProcess,String newProcess) {

		boolean sameprocess=false;

		if(oldProcess.contentEquals(newProcess)) {
			System.out.println("same process is running");

			sameprocess=true;

		}else {

			sameprocess=false;

		}

		return sameprocess;

	}

	public boolean timeDifferbetween2dates(String oldptrack,String  newtrack) {
		SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd HH:mm:ss");

		Date d1 = null;
		Date d2 = null;

		boolean dtimestampdifference=false;

		try {
			d1 = format.parse(oldptrack);
			d2 = format.parse(newtrack);

			//in milliseconds
			long diff = d2.getTime() - d1.getTime();

			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			long diffDays = diff / (24 * 60 * 60 * 1000);

			System.out.print(diffDays + " days, ");
			System.out.print(diffHours + " hours, ");
			System.out.print(diffMinutes + " minutes, ");
			System.out.print(diffSeconds + " seconds.");

			if(diffSeconds<=60&&diffMinutes==0&&diffHours==0&&diffDays==0) {
				dtimestampdifference=true;
			}

		} catch (Exception e) {
			dtimestampdifference=false;
			e.printStackTrace();
		}

		return dtimestampdifference;

	}
}

